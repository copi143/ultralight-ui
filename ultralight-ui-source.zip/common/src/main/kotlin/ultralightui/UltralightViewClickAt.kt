package ultralightui

enum class UltralightViewClickAt {
    Outside, Inside, TopLeftCorner, TopRightCorner, BottomLeftCorner, BottomRightCorner, LeftEdge, RightEdge, TopEdge, BottomEdge
}
